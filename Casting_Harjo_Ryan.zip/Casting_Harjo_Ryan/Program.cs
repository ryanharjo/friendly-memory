﻿namespace Casting_Harjo_Ryan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Ask the user to input a whole number.
            Console.Write("Please enter a whole number: ");

            // Assign the whole number to an integer variable.
            int favoriteNumber = int.Parse(Console.ReadLine());

            // Print out the user's favorite number.
            Console.WriteLine($"Your favorite number is {favoriteNumber}!");

            // Ask the user a 'yes' or 'no' question.
            Console.Write("Do you like video games? (Enter true or false): ");

            // Assign the input string to a boolean variable called isTrue.
            bool isTrue = bool.Parse(Console.ReadLine());

            // Print out a message based on the user's input.
            Console.WriteLine($"It is {isTrue} that I like video games!");
        }
    }
}
